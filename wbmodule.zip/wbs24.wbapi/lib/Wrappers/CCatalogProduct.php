<?php
namespace Wbs24\Wbapi\Wrappers;

class CCatalogProduct {
    public function Update(...$args) {
        return \CCatalogProduct::Update(...$args);
    }
}
