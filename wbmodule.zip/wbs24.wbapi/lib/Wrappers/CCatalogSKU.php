<?php
namespace Wbs24\Wbapi\Wrappers;

class CCatalogSKU {
    public function getOffersList(...$args) {
        return \CCatalogSKU::getOffersList(...$args);
    }

    public function GetProductInfo(...$args) {
        return \CCatalogSKU::GetProductInfo(...$args);
    }
}
