<?php
namespace Wbs24\Wbapi\Wrappers;

class CIBlock {
    public function GetList(...$args) {
        return \CIBlock::GetList(...$args);
    }
}
