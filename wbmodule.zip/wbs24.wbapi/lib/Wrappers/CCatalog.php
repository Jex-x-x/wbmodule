<?php
namespace Wbs24\Wbapi\Wrappers;

class CCatalog {
    public function GetByIDExt(...$args) {
        return \CCatalog::GetByIDExt(...$args);
    }
}
