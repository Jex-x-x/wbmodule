<?php
namespace Wbs24\Wbapi\Wrappers;

class CIBlockProperty
{
    public function GetList(...$args) {
        return \CIBlockProperty::GetList(...$args);
    }
}
