<?php
$MESS["WBS24.WBAPI.INSTALL_NAME"] = "WBS24: Обработка заказов с Wildberries по API";
$MESS["WBS24.WBAPI.INSTALL_DESCRIPTION"] = "Обработка заказов с Wildberries по API";
$MESS["WBS24.WBAPI.INSTALL_COMPANY_NAME"] = "WEB Симфония";
