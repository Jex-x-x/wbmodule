<?php
$suffix = strtoupper(basename(dirname(__DIR__, 3)));

$MESS[$suffix.".SETTINGS"] = "Настройки";
$MESS[$suffix.".TITLE"] = "Настройки";

$MESS[$suffix.".NEW_SETTINGS_VIEW"] = "Внимание! У нас обновился интерфейс настроек! ";
$MESS[$suffix.".NEW_SETTINGS_BTN"] = "Переходите в новый интерфейс.";

$MESS[$suffix.".NOTE"] = "Настройки модуля производятся по пути: <b>WEB Симфония > Wildberries > Профиль [номер_профиля]</b>.";
