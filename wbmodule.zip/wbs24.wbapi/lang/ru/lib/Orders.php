<?php
$suffix = strtoupper(basename(dirname(__DIR__, 3)));

$MESS[$suffix.".TRADING_PLATFORM_NAME"] = "Маркетплейс Wildberries";
$MESS[$suffix.".TRADING_PLATFORM_SKU"] = "SKU на Маркетплейсе";
$MESS[$suffix.".ERROR_ADD_PRODUCT_TO_BASKET"] =
    '<div>Недостаточное количество товара (ID = #PRODUCT_ID#, OFFER_ID = #OFFER_ID#) для добавления в корзину заказа.</div>'
;
