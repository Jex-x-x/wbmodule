<?php
$suffix = strtoupper(basename(dirname(__DIR__, 3)));

$MESS[$suffix.".WEB_SYMPHONY"] = "WEB Симфония";
    $MESS[$suffix.".WB_TITLE"] = "Wildberries";
    $MESS[$suffix.".ACCOUNT"] = "Профиль";
        $MESS[$suffix.".ACCOUNT_MAIN_SETTINGS"] = "Базовые настройки";
        $MESS[$suffix.".ACCOUNT_ORDER_SETTINGS"] = "Заказы";
        $MESS[$suffix.".ACCOUNT_PRICE_SETTINGS"] = "Обновление цен";
        $MESS[$suffix.".ACCOUNT_STOCK_SETTINGS"] = "Обновление остатков";
    $MESS[$suffix.".GROUP_RIGHTS"] = "Права доступа";
    $MESS[$suffix.".INSTRUCTION"] = "Инструкция";
