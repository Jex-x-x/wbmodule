<?php
$suffix = strtoupper(basename(dirname(__DIR__, 3)));

$MESS[$suffix.".CUSTOMER_ID_NOT_SELECTED"] = "Не выбрано";
