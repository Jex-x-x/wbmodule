<?php
$suffix = strtoupper(basename(dirname(__DIR__, 4)));

$MESS[$suffix.".BASKET_IS_WRONG"] = "Товары в корзине не соответствуют составу заказа на WB. Не хватает следующих позиций: ";
$MESS[$suffix.".PCS"] = "шт.";
