<?php
$suffix = strtoupper(basename(dirname(__DIR__, 3)));

$MESS[$suffix.".BLOCK_CAPTION"] = 'Список сборочных заданий в заказе';
$MESS[$suffix.".LIST_ASSEMBLY_TASKS"] = 'Номера сборочных заданий:';
