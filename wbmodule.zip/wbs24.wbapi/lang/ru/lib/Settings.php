<?php
$suffix = strtoupper(basename(dirname(__DIR__, 3)));

$MESS[$suffix.".NOT_SELECTED"] = "Не выбрано";
$MESS[$suffix.".DEFAULT"] = "По умолчанию";
$MESS[$suffix.".EXTERNAL_ID"] = "Внешний код";
$MESS[$suffix.".PRODUCTS_PROPERTIES_LABEL"] = "Свойства товара";
$MESS[$suffix.".OFFERS_PROPERTIES_LABEL"] = "Свойства ТП";

$MESS[$suffix.".CATALOG_QUANTITY"] = "Доступное количество";
$MESS[$suffix.".PRICES_FROM_PROPERTY"] = "Цены из свойств";
$MESS[$suffix.".STOCKS_FROM_PROPERTY"] = "Остатки из свойств";
