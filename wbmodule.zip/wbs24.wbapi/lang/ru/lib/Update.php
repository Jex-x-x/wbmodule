<?php
$suffix = strtoupper(basename(dirname(__DIR__, 3)));

$MESS[$suffix.".UPDATE_MESSAGE"] = "Доступно обновление модуля wbs24.wbapi версии";
$MESS[$suffix.".UPDATE_RUN"] = "Установить";
