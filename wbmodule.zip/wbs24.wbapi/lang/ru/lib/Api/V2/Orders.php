<?php
$suffix = strtoupper(basename(dirname(__DIR__, 5)));

$MESS[$suffix.".ENTRANCE"] = "вход";
