<?php
echo '{"data":{"cards":[{"sizes":[{"techSize":"0","skus":["5032781142964"]}],"mediaFiles":["http://imglink.com/imgOne.jpg"],"colors":["белый"],"updateAt":"2022-08-10T10:16:52Z","vendorCode":"670000001","brand":"Шанель","object":"Туалетная вода","nmID":66964167}],"cursor":{"updatedAt":"2022-08-10T10:16:52Z","nmID":66964167,"total":1}},"error":false,"errorText":"","additionalErrors":null}';
