<?php
    echo '{"data":{"uploadID":1001,"historyGoods":[{"nmID":66964167,"vendorCode":"23083","sizeID":54483342,"price":8990,"currencyIsoCode4217":"RUB","discount":25,"status":1,"errorText":""}]}}';
