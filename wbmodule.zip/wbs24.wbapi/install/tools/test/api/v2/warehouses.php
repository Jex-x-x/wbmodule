<?php
echo '[{"id":5235,"name":"string"}]';
