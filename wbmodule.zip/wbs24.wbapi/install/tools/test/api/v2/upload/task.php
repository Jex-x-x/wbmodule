<?php
echo '{"data":{"id":1001,"alreadyExists":false},"error":false,"errorText":""}';