<?php
echo '[{"nmId":114296358,"price":8390,"discount":0,"promoCode":0},{"nmId":66964167,"price":7620,"discount":0,"promoCode":0}]';
