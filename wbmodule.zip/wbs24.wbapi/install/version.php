<?php
$arModuleVersion = [
    "VERSION" => "0.8.0",
    "VERSION_DATE" => "2024-09-02",
];
