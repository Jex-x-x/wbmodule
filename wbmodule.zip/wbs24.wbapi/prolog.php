<?php
$moduleId = basename(__DIR__);

define("ADMIN_MODULE_NAME", $moduleId);
define("ADMIN_MODULE_ICON", "");
